//
//  JokeModel.swift
//  TableViewApi
//
//  Created by Sharma Aryan on 15/10/24.
//

import Foundation
struct JokeModel:Codable{
    var type:String
    var setup:String
    var punchline:String
    var id:Int
}
