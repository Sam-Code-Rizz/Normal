//
//  DetailVc.swift
//  TableViewApi
//
//  Created by Sharma Aryan on 15/10/24.
//

import UIKit

class DetailVc: UIViewController {
    var CurrentJoke:JokeModel!

    @IBOutlet weak var punchline: UILabel!
    @IBOutlet weak var Setup: UILabel!
    @IBOutlet weak var Types: UILabel!
    @IBOutlet weak var Id: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        punchline.text=CurrentJoke.punchline
        Id.text=String(CurrentJoke.id)
        Types.text=CurrentJoke.type
        Setup.text=CurrentJoke.setup
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
