//
//  ViewController.swift
//  TableViewApi
//
//  Created by Sharma Aryan on 15/10/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    var jokes:[JokeModel]=[]
    private var SelectedJoke:JokeModel!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return jokes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        cell.Id.text=String(jokes[indexPath.row].id)
        cell.Types.text=jokes[indexPath.row].type
        cell.Setup.text=jokes[indexPath.row].setup
        cell.Punchline.text=jokes[indexPath.row].punchline
        
        return cell
    }
    func Apicall(){
        ApiManager().FetchJokesApi{
            result in switch result{
            case .success(let data):
                self.jokes.append(contentsOf: data)
                self.Table.reloadData()
            case .failure(let error):
                debugPrint("Error \(error)")
            }
    
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        400
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        SelectedJoke=jokes[indexPath.row]
        performSegue(withIdentifier: "GoToNext", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier=="GoToNext"
        {
            if let Detailvc=segue.destination as? DetailVc
            {
                Detailvc.CurrentJoke=SelectedJoke
            }
        }
    }
//    @IBOutlet weak var Table: UINavigationItem!
    @IBOutlet weak var Table: UINavigationItem!
    
    override func viewDidLoad() {
    
        super.viewDidLoad()
        Table.dataSource=self
        Table.delegate=self
        Table.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell")
        Apicall()
        // Do any additional setup after loading the view.
    }


}

