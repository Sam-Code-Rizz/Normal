//
//  TableViewCell.swift
//  TableViewApi
//
//  Created by Sharma Aryan on 15/10/24.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var Punchline: UILabel!

    
    @IBOutlet weak var Types: UILabel!
    @IBOutlet weak var Setup: UILabel!
    @IBOutlet weak var Id: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
