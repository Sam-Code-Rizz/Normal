//
//  ViewController.swift
//  SliderDemo
//
//  Created by Sharma Aryan on 21/12/24.
//
import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var opacitySlider: UISlider!
    @IBOutlet weak var bslider: UISlider!
    @IBOutlet weak var gslider: UISlider!
    @IBOutlet weak var rslider: UISlider!
    @IBOutlet weak var ColoeView: UIView!
    
    @IBOutlet var mainView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        mainView.backgroundColor = hexToColor(hex: CDManager().ReadCD().color)
        // Do any additional setup after loading the view.
    }
    
    @IBAction func SliderBtn(_ sender: Any) {
        let r = CGFloat(rslider.value)
        let g = CGFloat(gslider.value)
        let b = CGFloat(bslider.value)
        let o = CGFloat(opacitySlider.value)
        mainView.backgroundColor = UIColor(red:r/255,green:g/255,blue:b/255,alpha:o)
        
        
    }
    
    func chnageColor(r:CGFloat,g:CGFloat,b:CGFloat,o:CGFloat){
        ColoeView.backgroundColor = UIColor(red:r/255,green:g/255,blue:b/255,alpha:o)
    }
    
    @IBAction func rsliderLayout(_ sender: Any) {
        var r = CGFloat(rslider.value)
        var g = CGFloat(gslider.value)
        var b = CGFloat(bslider.value)
        var o = CGFloat(opacitySlider.value)
        chnageColor(r: r, g: g, b: b, o: o)
        
    }
    
    
    @IBAction func gsliderLayout(_ sender: Any) {
        var r = CGFloat(rslider.value)
        var g = CGFloat(gslider.value)
        var b = CGFloat(bslider.value)
        var o = CGFloat(opacitySlider.value)
        chnageColor(r: r, g: g, b: b, o: o)
        
    }
    
    
    @IBAction func bsliderLayout(_ sender: Any) {
        var r = CGFloat(rslider.value)
        var g = CGFloat(gslider.value)
        var b = CGFloat(bslider.value)
        var o = CGFloat(opacitySlider.value)
        chnageColor(r: r, g: g, b: b, o: o)
        
    }
    
    
    @IBAction func opacityLayout(_ sender: Any) {
        var r = CGFloat(rslider.value)
        var g = CGFloat(gslider.value)
        var b = CGFloat(bslider.value)
        var o = CGFloat(opacitySlider.value)
        chnageColor(r: r, g: g, b: b, o: o)
        
    }
    
    func colorToHex(color: UIColor) -> String {
        var red: CGFloat = 0
        var green: CGFloat = 0
        var blue: CGFloat = 0
        var alpha: CGFloat = 0
        
        // Extract the RGBA components from the UIColor
        color.getRed(&red, green: &green, blue: &blue, alpha: &alpha)
        
        // Convert components to HEX (0-255 range)
        let r = Int(red * 255)
        let g = Int(green * 255)
        let b = Int(blue * 255)
        let a = Int(alpha * 255)
        
        // Return the HEX string (ignoring alpha for now)
        return String(format: "#%02X%02X%02X", r, g, b, a)
    }
    
    func hexToColor(hex: String) -> UIColor? {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")
        
        guard hexSanitized.count == 6 || hexSanitized.count == 8 else { return nil }
        
        var rgb: UInt64 = 0
        Scanner(string: hexSanitized).scanHexInt64(&rgb)
        
        let red = CGFloat((rgb & 0xFF000000) >> 24) / 255.0
        let green = CGFloat((rgb & 0x00FF0000) >> 16) / 255.0
        let blue = CGFloat((rgb & 0x0000FF00) >> 8) / 255.0
        let alpha = hexSanitized.count == 8 ? CGFloat(rgb & 0x000000FF) / 255.0 : 1.0
        
        return UIColor(red: red, green: green, blue: blue, alpha: alpha)
    }
}


