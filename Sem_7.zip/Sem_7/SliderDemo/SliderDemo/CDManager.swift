//
//  CDManager.swift
//  SliderDemo
//
//  Created by Sharma Aryan on 21/12/24.
//

import Foundation
import CoreData
import UIKit

class CDManager {
    let delegate = UIApplication.shared.delegate as? AppDelegate
    
    func SaveCD(save: ColorModel){
        guard let managedContext = delegate?.persistentContainer.viewContext else { return }
        
        guard let colorEntity = NSEntityDescription.entity(forEntityName: "ColorEntity", in: managedContext) else {return}
        
        let Data = NSManagedObject(entity: colorEntity, insertInto: managedContext)
        Data.setValue(save.color, forKey: "color")
        
        do{
            try managedContext.save()
            print("Color Saved successfully!")
        }
        catch let err as NSError{
            debugPrint(err)
        }
    }
    
    func ReadCD()-> ColorModel{
        var colors: [ColorModel] = []
        let managedContext = delegate?.persistentContainer.viewContext
        
        let fetchRes = NSFetchRequest<NSFetchRequestResult>(entityName: "ColorEntity")
        
        do{
            let dataArr = try managedContext?.fetch(fetchRes)
            for d in dataArr as! [NSManagedObject]{
                let color = d.value(forKey: "color") as! String
                colors.append(ColorModel(color: color))
            }
        }
        catch let err as NSError{
            debugPrint(err)
        }
        return colors[0]
    }
}
