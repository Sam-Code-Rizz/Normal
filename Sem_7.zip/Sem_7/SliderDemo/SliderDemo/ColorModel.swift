//
//  ColorModel.swift
//  SliderDemo
//
//  Created by Sharma Aryan on 21/12/24.
//

import Foundation

struct ColorModel:Codable {
    var id = UUID()
    var color: String
}
