//
//  ConstantStrings.swift
//  table-tea
//
//  Created by Jaimin Raval on 01/10/24.
//

import Foundation


final class K {
    static let JokeCellIdentifier = "JokeCell"
    static let CollectionCellIdentifier = "CollectionCell"
    static let JokeDetailSegue = "GoToDetailVC"
    static let DetailSegue = ""
}
