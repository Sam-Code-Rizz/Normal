//
//  CollectionCell.swift
//  table-tea
//
//  Created by Jaimin Raval on 17/09/24.
//

import UIKit

class CollectionCell: UICollectionViewCell {

    @IBOutlet weak var jokeLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
