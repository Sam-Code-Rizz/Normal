//
//  TableCell.swift
//  SegmentControlTest
//
//  Created by Sharma Aryan on 19/12/24.
//

import UIKit

class TableCell: UITableViewCell {

    @IBOutlet weak var quote: UILabel!
    @IBOutlet weak var religion: UILabel!
    @IBOutlet weak var source: UILabel!
    @IBOutlet weak var id: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
