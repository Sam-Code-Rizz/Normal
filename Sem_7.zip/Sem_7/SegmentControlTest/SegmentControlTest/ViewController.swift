//
//  ViewController.swift
//  SegmentControlTest
//
//  Created by Sharma Aryan on 19/12/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
                self.CoreData = CDManager().ReadCD()
        self.reloadTable()
        
    }
    
    var CoreData: [QuoteModel] = []
    var QuotesApi: [QuoteModel] = []
    @IBOutlet weak var SegmentBtn: UISegmentedControl!
    @IBOutlet weak var ApiTable: UITableView!
    @IBOutlet weak var saveTable: UITableView!
    var selectedQuote: QuoteModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ApiTable.delegate = self
        ApiTable.dataSource = self
        ApiTable.register(UINib(nibName: "TableCell", bundle: nil), forCellReuseIdentifier: "TableCell")
        
        saveTable.delegate = self
        saveTable.dataSource = self
        saveTable.register(UINib(nibName: "TableCell", bundle: nil), forCellReuseIdentifier: "TableCell")
        
        saveTable.isHidden = true
        self.CoreData = CDManager().ReadCD()
        
        fetchAF {
            response in
            switch response {
                
            case .success(let data):
                self.QuotesApi.append(contentsOf: data)
                self.reloadTable()
                
                
            case .failure(let error):
                debugPrint(error)
            }
        }
        self.reloadTable()
        
        SegmentBtn.selectedSegmentIndex = 0
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableView == ApiTable ? QuotesApi.count : CoreData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableCell", for: indexPath) as! TableCell
        if tableView == ApiTable {
            cell.id.text = "\(QuotesApi[indexPath.row].id)"
            cell.source.text = QuotesApi[indexPath.row].source
            cell.religion.text = QuotesApi[indexPath.row].religion
            cell.quote.text = QuotesApi[indexPath.row].quote
        }
        else {
            cell.id.text = "\(CoreData[indexPath.row].id)"
            cell.source.text = CoreData[indexPath.row].source
            cell.religion.text = CoreData[indexPath.row].religion
            cell.quote.text = CoreData[indexPath.row].quote
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 300
    }
    
    @IBAction func changeSegment(_ sender: Any) {
        if SegmentBtn.selectedSegmentIndex == 0 {
            ApiTable.isHidden = false
            saveTable.isHidden = true
            reloadTable()
        }
        else {
            ApiTable.isHidden = true
            saveTable.isHidden = false
            self.CoreData = CDManager().ReadCD()
            reloadTable()
        }
        
        
    }
    
    func reloadTable() {
        DispatchQueue.main.async {
            if self.SegmentBtn.selectedSegmentIndex == 0 {
                self.ApiTable.reloadData()
            } else if self.SegmentBtn.selectedSegmentIndex == 1{
                self.saveTable.reloadData()
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == ApiTable {
            CDManager().saveCD(quoteData: QuotesApi[indexPath.row])
            debugPrint("Print Inside APITable")
        }
    }
    
    func deleteFromArr(position: Int) {
        CoreData.remove(at: position)
        DispatchQueue.main.async {
            self.saveTable.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        if tableView == saveTable {
            let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { [self] _, _, completionHandler in
                
                let quote = self.CoreData[indexPath.row]
                CDManager().DeleteCD(quoteDelete: quote)
                
                deleteFromArr(position: indexPath.row)
                
                tableView.performBatchUpdates {
                    tableView.deleteRows(at: [indexPath], with: .automatic)
                } completion: { _ in
                    completionHandler(true)
                }
            }
            deleteAction.image = UIImage(systemName: "minus.circle.fill")
            let deleteConfig = UISwipeActionsConfiguration(actions: [deleteAction])
            return deleteConfig
        } else {
            let deleteConfig = UISwipeActionsConfiguration(actions: [])
            
            return deleteConfig
        }
    }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        if tableView == saveTable {
            let updateAction = UIContextualAction(style: .normal, title: "Edit") { [weak self] _, _, completionHandler in
                guard let self = self else { return }
                self.selectedQuote = self.CoreData[indexPath.row]
                self.performSegue(withIdentifier: "UpdateQuote", sender: indexPath)
                completionHandler(true)
            }
            updateAction.backgroundColor = .systemBlue
            updateAction.image = UIImage(systemName: "rectangle.and.pencil.and.ellipsis")
            return UISwipeActionsConfiguration(actions: [updateAction])
        }
        return UISwipeActionsConfiguration(actions: [])
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "UpdateQuote",
           let updateVC = segue.destination as? UpdateVCViewController {
            updateVC.selectedQuote = self.CoreData[(sender as! IndexPath).row]
        }
    }

    
}

