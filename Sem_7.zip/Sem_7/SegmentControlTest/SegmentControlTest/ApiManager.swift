//
//  ApiManager.swift
//  SegmentControlTest
//
//  Created by Sharma Aryan on 19/12/24.
//

import Foundation
import Alamofire

    let urlstr = "https://fight-addictions-api.deno.dev/spiritual/quotes/buddhism"
    
    func fetchAF(completionHandler: @escaping(Result<[QuoteModel], Error>) -> Void) {
        
        AF.request(urlstr).responseDecodable(of: [QuoteModel].self) { response in
            
            switch response.result {
                
            case .success(let data):
                completionHandler(.success(data))
                
            case .failure(let error):
                completionHandler(.failure(error))
            }
            
        }
    }

