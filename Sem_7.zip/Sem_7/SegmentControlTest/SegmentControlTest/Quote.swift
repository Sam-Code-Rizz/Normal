//
//  Quote.swift
//  SegmentControlTest
//
//  Created by Sharma Aryan on 19/12/24.
//

import Foundation

struct QuoteModel:Codable {
    var id: Int64
    var quote: String
    var religion: String
    var source: String
}
