//
//  UpdateVCViewController.swift
//  SegmentControlTest
//
//  Created by Sharma Aryan on 19/12/24.
//

import UIKit

class UpdateVCViewController: UIViewController {

    @IBOutlet weak var updateBtn: UIButton!
    @IBOutlet weak var updateQuote: UITextField!
    @IBOutlet weak var updateSource: UITextField!
    @IBOutlet weak var updatereligion: UITextField!
    var selectedQuote: QuoteModel!
    override func viewDidLoad() {
        super.viewDidLoad()
        updateQuote.text = selectedQuote.quote
        updatereligion.text = selectedQuote.religion
        updateSource.text = selectedQuote.source
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func updateAction(_ sender: Any) {
        guard let quoteText = updateQuote.text,
              let religionText = updatereligion.text,
              let sourceText = updateSource.text else { return }
              
        CDManager().UpdateCD(quoteUpdate: QuoteModel(
            id: selectedQuote.id,
            quote: quoteText,
            religion: religionText,
            source: sourceText
        ))
    }

    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
