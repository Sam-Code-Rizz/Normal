//
//  CDManager.swift
//  SegmentControlTest
//
//  Created by Sharma Aryan on 19/12/24.
//

import Foundation
import CoreData
import UIKit

class CDManager {
    let delegate = UIApplication.shared.delegate as? AppDelegate
    
    func ReadCD()-> [QuoteModel] {
        let managedContext = self.delegate?.persistentContainer.viewContext
        var quotes: [QuoteModel] = []
        let fetchres = NSFetchRequest<NSFetchRequestResult>(entityName: "QuoteEntity")
        
        do {
            let DataArr = try managedContext?.fetch(fetchres)
            for item in DataArr as! [NSManagedObject]{
                let id = item.value(forKey: "id") as! Int64
                let quote = item.value(forKey: "quote") as! String
                let source = item.value(forKey: "source") as! String
                let religion = item.value(forKey: "religion") as! String
                quotes.append(QuoteModel(id: id, quote: quote, religion: religion, source: source))
            }
        }
        catch let err as NSError
        {
            debugPrint(err)
        }
        return quotes
    }
    
    func saveCD(quoteData: QuoteModel) {
        guard let managedContext = self.delegate?.persistentContainer.viewContext else { return }
        
        guard let QuoteEntity = NSEntityDescription.entity(forEntityName: "QuoteEntity", in: managedContext) else {return}
        
        let quote = NSManagedObject(entity: QuoteEntity, insertInto: managedContext)
        
        quote.setValue(quoteData.id, forKey: "id")
        quote.setValue(quoteData.source, forKey: "source")
        quote.setValue(quoteData.religion, forKey: "religion")
        quote.setValue(quoteData.quote, forKey: "quote")
        
        do {
            try managedContext.save()
            debugPrint("Data saved Successfully...")
        }
        catch let err as NSError {
            debugPrint(err)
        }
        
    }
    
    func UpdateCD(quoteUpdate: QuoteModel) {
            let managedContext = self.delegate?.persistentContainer.viewContext
            
            let fetchRes = NSFetchRequest<NSFetchRequestResult>(entityName: "QuoteEntity")
            
            fetchRes.predicate = NSPredicate(format: "id = %d", quoteUpdate.id)
            
            do {
                let result = try managedContext?.fetch(fetchRes)
                if let resultData = result as? [NSManagedObject] {
                    for object in resultData {
                        object.setValue(quoteUpdate.quote, forKey: "quote")
                        object.setValue(quoteUpdate.source, forKey: "source")
                        object.setValue(quoteUpdate.religion, forKey: "religion")
                    }
                    try managedContext?.save()
                    debugPrint("Data updated Successfully...")
                }
            } catch let err as NSError {
                debugPrint(err)
            }
        }
    
    func DeleteCD(quoteDelete: QuoteModel) {
        guard let managedContext = self.delegate?.persistentContainer.viewContext else { return }
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "QuoteEntity")
        fetchRequest.predicate = NSPredicate(format: "id = %d", quoteDelete.id)
        
        do {
            let result = try managedContext.fetch(fetchRequest)
            if let resultData = result as? [NSManagedObject] {
                for object in resultData {
                    managedContext.delete(object)
                }
                try managedContext.save()
                debugPrint("Data deleted Successfully...")
            }
        } catch let err as NSError {
            debugPrint(err)
        }
    }
}

