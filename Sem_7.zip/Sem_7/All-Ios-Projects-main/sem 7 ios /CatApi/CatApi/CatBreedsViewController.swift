import UIKit
import AlamofireImage // For loading image from URL

class CatBreedsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var catBreedsTableView: UITableView!
    var catBreeds: [CatBreed] = []

    override func viewDidLoad() {
        super.viewDidLoad()

        // Set the data source and delegate
        catBreedsTableView.dataSource = self
        catBreedsTableView.delegate = self
        let nib = UINib(nibName: "TableViewCell", bundle: nil)
        catBreedsTableView.register(nib, forCellReuseIdentifier: "CatBreedCell")

        catBreedsTableView.rowHeight = 300  //Adjust as needed

        // Fetch cat breeds data
        CatBreedService().fetchCatBreeds { [weak self] breeds in
            guard let self = self, let breeds = breeds else { return }
            self.catBreeds = breeds
            DispatchQueue.main.async {
                self.catBreedsTableView.reloadData()
            }
        }
    }

    // TableView DataSource Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return catBreeds.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CatBreedCell", for: indexPath) as! TableViewCell
        let breed = catBreeds[indexPath.row]

        // Configure the cell with data
        cell.nameLabel.text = breed.name
        cell.originLabel.text = "Origin: \(breed.origin)" // This will work now
        cell.temperamentLabel.text = "Temperament: \(breed.temperament)"

        // Load image using AlamofireImage
        if let imageUrl = URL(string: breed.image) {
            cell.imgView.af.setImage(withURL: imageUrl)
        }

        return cell
    }
}
