import Foundation

struct CatBreed: Codable {
    let id: Int
    let name: String
    let origin: String
    let temperament: String
    let colors: [String]
    let description: String
    let image: String
}
//
take input from the user in and save that input in userdefault. on pressing the next button navigate to the next screen which contains
