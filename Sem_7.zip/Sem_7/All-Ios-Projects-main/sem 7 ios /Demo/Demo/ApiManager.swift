//
//  ApiManager.swift
//  Demo
//
//  Created by ADMIN on 17/09/24.
//

import Foundation
import Alamofire

class ApiManager{
    static let urlstr="https://official-joke-api.appspot.com/jokes/random/25"
    
    static func fectchJokesAF(){
        var jokeData:[JokeModel] = []
        AF.request(urlstr).response{response in
            
            switch response.result{
            case .success(let data):
                print(data)
            case .failure(let error):
                print(error)
            }
        }
    }
}
