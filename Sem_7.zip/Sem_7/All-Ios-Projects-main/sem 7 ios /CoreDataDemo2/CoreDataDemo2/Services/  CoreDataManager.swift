//
//  CoreDataManager.swift
//  CoreDataDemo2
//
//  Created by ADMIN on 24/09/24.
//

import Foundation
import UIKit
import CoreData

final class CoreDataManager{
    static func addToCoreData(userData: UserModel){
        
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let managedContext = delegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequest<NSFetchRequestResult>>(entityName: "Jokes")
        
        guard let userEntity = NSEntityDescription.entity(forEntityName: "User", in: managedContext) else { return}
        let user = NSManagedObject(entity: userEntity, insertInto: managedContext)
        
        user.setValue(userData.id, forKey: "id")
        user.setValue(userData.name, forKey: "name")
        user.setValue(userData.email, forKey: "email")
        
        do{
            try managedContext.save()
            debugPrint("Data Saved")
            
        } catch let err as NSError{
            debugPrint("The error \(err)")
        }
    }
}
