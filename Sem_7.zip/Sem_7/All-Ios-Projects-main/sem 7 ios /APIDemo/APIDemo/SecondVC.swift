//
//  SecondVC.swift
//  APIDemo
//
//  Created by ADMIN on 09/12/24.
//

import UIKit

class SecondVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    

    @IBOutlet weak var segmentController: UISegmentedControl!
    @IBOutlet weak var table2: UITableView!
    @IBOutlet weak var table1: UITableView!
    var jokes : [jokeModel] = []
    var user : [jokeModel] = []
    
    override func viewWillAppear(_ animated: Bool) {
        ApiCall{
            res in
            switch res {
            case .success(let data):
                self.jokes.append(contentsOf: data)
                self.table1.reloadData()
            case .failure(let failure):
                debugPrint(failure)
            }
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        table1.dataSource = self
        table1.delegate = self
        
        table2.dataSource = self
        table2.delegate = self
        
        table1.register(UINib(nibName: "TVCell", bundle: nil), forCellReuseIdentifier: "TVCell")
        table2.register(UINib(nibName: "TVCell", bundle: nil), forCellReuseIdentifier: "TVCell")

        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return jokes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TVCell", for: indexPath) as! TVCell
        cell.lbl1.text = jokes[indexPath.row].type
        cell.lbl2.text = jokes[indexPath.row].setup
        cell.lbl3.text = jokes[indexPath.row].punchline
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
}
