//
//  jokeModel.swift
//  APIDemo
//
//  Created by ADMIN on 09/12/24.
//

import Foundation
struct jokeModel : Codable{
    let id : Int
    let type : String
    let setup : String
    let punchline : String
}
