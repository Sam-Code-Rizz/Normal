//
//  gridCell.swift
//  Collection_View
//
//  Created by ADMIN on 16/08/24.
//

import UIKit

class gridCell: UICollectionViewCell {
    
    @IBOutlet weak var label: UILabel!
}
