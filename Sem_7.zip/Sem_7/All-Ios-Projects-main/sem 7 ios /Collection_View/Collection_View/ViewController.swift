import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    var width: CGFloat!
    var height: CGFloat!
    @IBOutlet weak var gridCollection: UICollectionView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // getting size of current device
        width = view.bounds.size.width
        height = view.bounds.size.height
        
       // init CollectionView
        gridCollection.dataSource = self
        gridCollection.delegate = self
        
        // Do any additional setup after loading the view.
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (width / 5), height: 128)
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 40
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "gridCell", for: indexPath) as! gridCell
        cell.label.text = "Data \(indexPath.item)"
        return cell
    }
}

