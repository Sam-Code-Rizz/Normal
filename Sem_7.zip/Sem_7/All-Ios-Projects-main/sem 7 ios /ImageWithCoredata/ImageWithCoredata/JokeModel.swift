//
//  JokeModel.swift
//  ImageWithCoredata
//
//  Created by ADMIN on 30/11/24.
//

import Foundation


struct JokeModel: Codable {
    let id: Int
    let type: String
    let setup: String
    let punchline: String
    
}
