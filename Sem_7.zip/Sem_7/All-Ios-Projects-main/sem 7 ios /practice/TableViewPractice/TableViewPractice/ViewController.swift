//
//  ViewController.swift
//  TableViewPractice
//
//  Created by ADMIN on 23/09/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        20
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "table", for: indexPath) as! TableViewCell
        cell.FirstLabel.text="Hello world"
        return cell
    }
    

    @IBOutlet weak var TableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        TableView.delegate=self
        TableView.dataSource=self
        // Do any additional setup after loading the view.
    }
    


}

