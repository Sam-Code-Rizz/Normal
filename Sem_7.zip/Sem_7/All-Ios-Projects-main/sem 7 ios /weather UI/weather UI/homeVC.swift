//
//  ViewController.swift
//  weather UI
//
//  Created by ADMIN on 01/08/24.
//

import UIKit

class homeVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var bgimagie: UIImageView!
    

}

