//
//  TableController.swift
//  SpeedRun
//
//  Created by ADMIN on 03/10/24.
//

import Foundation
import UIKit
class TableController:UIViewController{
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    \
}
