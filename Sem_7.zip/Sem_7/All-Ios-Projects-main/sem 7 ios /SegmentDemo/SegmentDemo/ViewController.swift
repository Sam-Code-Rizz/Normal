//
//  ViewController.swift
//  SegmentDemo
//
//  Created by ADMIN on 09/12/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    @IBOutlet weak var segmentController: UISegmentedControl!
    @IBOutlet weak var tabelmain: UITableView!
    @IBOutlet weak var tablemain1: UITableView!
    
    var fruite = ["apple","banana","mango","graps"]
    var days = ["monday","tuesday","sunday","saturday"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tabelmain.dataSource = self
        tabelmain.delegate = self
        
        tablemain1.dataSource = self
        tablemain1.delegate = self
        
        // Do any additional setup after loading the view.
        tabelmain.register(UINib(nibName: "TVCell", bundle: nil), forCellReuseIdentifier: "TVCell")
        tablemain1.register(UINib(nibName: "TVCell", bundle: nil), forCellReuseIdentifier: "TVCell")
        
//        segmentController.selectedSegmentIndex = 0
//        segmentAction(segmentController)

        
    }
    
    @IBAction func segmentAction(_ sender: Any) {
        if segmentController.selectedSegmentIndex == 0{
            tabelmain.isHidden = false
            tablemain1.isHidden  = true
            self.tabelmain.reloadData()
        }
        else if segmentController.selectedSegmentIndex == 1{
            tabelmain.isHidden = true
            tablemain1.isHidden = false
            self.tablemain1.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       var count = 0
        if tableView == tabelmain{
            count = fruite.count
            return count
        }
        else if tableView == tablemain1{
            count = days.count
            return count
        }
        return count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TVCell", for: indexPath) as! TVCell
        if tableView == tabelmain{
            cell.lbl1.text = fruite[indexPath.row]
        }
        else if tableView == tablemain1{
            cell.lbl1.text = days[indexPath.row]
        }
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}

