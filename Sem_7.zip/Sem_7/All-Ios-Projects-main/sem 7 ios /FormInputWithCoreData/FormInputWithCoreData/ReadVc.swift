//
//  ReadVc.swift
//  apiCoreDataP
//
//  Created by Mobile5 on 28/11/24.
//

import UIKit
import CoreData

class ReadVc: UIViewController {

   
    @IBOutlet weak var tableRead: UITableView!
    var fetchedStudents : [StudentModel] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

         readFromCoreData()
        setup()
    
    }
    
}


extension ReadVc : UITableViewDelegate,UITableViewDataSource{
    
    func setup(){
        
        tableRead.delegate = self
        tableRead.dataSource = self
        tableRead.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "cell")
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  fetchedStudents.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        
        cell.idlbl.text = String(fetchedStudents[indexPath.row].id)
        cell.namelbl.text = fetchedStudents[indexPath.row].name
        cell.emaillbl.text = fetchedStudents[indexPath.row].email
        cell.streamlbl.text = fetchedStudents[indexPath.row].stream
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
    
    func readFromCoreData(){
        
      guard let delegate = UIApplication.shared.delegate as? AppDelegate  else{ return}
        
        let managedcontext = delegate.persistentContainer.viewContext
        
        let fetchRequest =  NSFetchRequest<NSFetchRequestResult>(entityName: "Student")
        
        
        do{
            let res = try managedcontext.fetch(fetchRequest)
            
            for data in res as! [NSManagedObject]{
                
                let jid = data.value(forKey: "id") as! Int
                let jname = data.value(forKey: "name") as! String
                let jemail = data.value(forKey: "email") as! String
                let jstream = data.value(forKey: "stream") as! String
                
                fetchedStudents.append(StudentModel(id: jid, name: jname, email: jemail, stream: jstream))
                
                DispatchQueue.main.async {
                    self.tableRead.reloadData()
                }
                
                print(data.value(forKey: "id") as! Int32)
                print(data.value(forKey: "name") as! String)
                print(data.value(forKey: "email") as! String)
                print(data.value(forKey: "stream") as! String)
                
            }
        }
        catch let err as NSError{
            debugPrint("Error :: \(NSError.self)")
        }
        
    }
    
}

