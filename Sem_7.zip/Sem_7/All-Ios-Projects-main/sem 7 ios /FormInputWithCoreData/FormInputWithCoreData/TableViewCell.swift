//
//  TableViewCell.swift
//  FormInputWithCoreData
//
//  Created by Mobile5 on 28/11/24.
//

import UIKit

class TableViewCell: UITableViewCell {

    
    @IBOutlet weak var idlbl: UILabel!
    @IBOutlet weak var namelbl: UILabel!
    @IBOutlet weak var emaillbl: UILabel!
    @IBOutlet weak var streamlbl: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
