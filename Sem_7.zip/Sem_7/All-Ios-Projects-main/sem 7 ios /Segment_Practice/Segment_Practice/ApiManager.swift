import Foundation
import Alamofire

class ApiManager{
    let url: String = "https://official-joke-api.appspot.com/jokes/random/25"
    var jokesRespone: [Model] = []
    func fetchJokesAF(completionHandler: @escaping(Result<[Model], Error>) -> Void){
        AF.request(url).responseDecodable(of: [Model].self){ response in
            switch response.result{
            case .success(let data):
                completionHandler(.success(data))
            case .failure(let error):
                completionHandler(.failure(error))
            }
            
        }
    }
    
}
