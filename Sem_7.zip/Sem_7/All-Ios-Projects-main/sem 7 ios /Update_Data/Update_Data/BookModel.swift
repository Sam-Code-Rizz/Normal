//
//  BookModel.swift
//  Update_Data
//
//  Created by ADMIN on 07/12/24.
//

import Foundation

struct BookModel: Codable {
    
    var id = UUID()
    var bookid: Int32
    var name: String
    var author: String
    var ISBN: String
    
}
