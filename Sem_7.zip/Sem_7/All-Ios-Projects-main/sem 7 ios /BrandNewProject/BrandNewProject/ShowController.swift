//
//  ShowController.swift
//  BrandNewProject
//
//  Created by ADMIN on 03/10/24.
//

import Foundation
import UIKit
class ShowController: UIViewController{
    @IBOutlet weak var nameLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        let name = UserDefaults.standard.string(forKey: "UserName")
        nameLabel.text! = name!
    }
}
