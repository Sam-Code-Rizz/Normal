//
//  DetailVC.swift
//  MovieCoreData
//
//  Created by Sharma Aryan on 22/12/24.
//

import UIKit


var movieArr:[MovieModel]=[]

class DetailVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        movieArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "TableCell", for: indexPath) as! TableCell
        let movie=movieArr[indexPath.row]
        cell.id.text=movie.id.uuidString
        cell.movie.text=movie.movie
        let strRating = String(movie.rating)
        cell.rating.text=strRating
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        250
    }
    

    @IBOutlet weak var Table: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Table.delegate=self
        Table.dataSource=self
        Table.register(UINib(nibName: "TableCell", bundle: nil), forCellReuseIdentifier: "TableCell")
        movieArr=CDManager().ReadCoreData()
        Table.reloadData()
        
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { _, _, completionHandler in

            let movie = movieArr[indexPath.row]
            CDManager().DeleteCoreData(movies: movie)
            
            movieArr.remove(at: indexPath.row)
            
            // Update the table view
            tableView.performBatchUpdates {
                tableView.deleteRows(at: [indexPath], with: .automatic)
            } completion: { _ in
                completionHandler(true)
            }
        }
        
        let updateAction = UIContextualAction(style: .normal, title: "Edit") { _, _, completionHandler in
                    
                    self.performSegue(withIdentifier: "updatedmovie", sender: indexPath)
                    completionHandler(true)
            
                }
                updateAction.backgroundColor = .systemBlue
        
                
        
        return UISwipeActionsConfiguration(actions: [deleteAction,updateAction])
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "updatedmovie",
           let destination = segue.destination as? UpdateVC,
           let indexPath = sender as? IndexPath {
            destination.movie = movieArr[indexPath.row]
        }
    }


    override func viewDidAppear(_ animated: Bool) {
        Table.reloadData()
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
