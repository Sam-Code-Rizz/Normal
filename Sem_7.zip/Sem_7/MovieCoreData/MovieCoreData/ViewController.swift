//
//  ViewController.swift
//  MovieCoreData
//
//  Created by Sharma Aryan on 22/12/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var fetch: UIButton!
    @IBOutlet weak var submit: UIButton!
    @IBOutlet weak var rating: UITextField!
    @IBOutlet weak var movie: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func fetchAction(_ sender: Any) {
        
    }
    @IBAction func submitAction(_ sender: Any) {
        let movieData=movie.text!
        let ratingData=rating.text!
        let rating=Double(ratingData)!
        let movie=MovieModel(movie: movieData, rating: rating)
        CDManager().AddToCoreData(movie: movie)
    }
    
}

