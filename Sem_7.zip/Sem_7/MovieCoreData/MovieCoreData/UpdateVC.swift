//
//  UpdateVC.swift
//  MovieCoreData
//
//  Created by Sharma Aryan on 22/12/24.
//

import UIKit

class UpdateVC: UIViewController {

    @IBOutlet weak var updateBtn: UIButton!
    @IBOutlet weak var updatedRating: UITextField!
    @IBOutlet weak var updatedMovie: UITextField!
    
    var movie: MovieModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let movie = movie {
            updatedMovie.text = movie.movie
            updatedRating.text = String(movie.rating)
        }

        // Do any additional setup after loading the view.
    }
    @IBAction func updateAction(_ sender: Any) {
        guard let updatedMovieData = updatedMovie.text, !updatedMovieData.isEmpty,
              let updatedRatingData = updatedRating.text, !updatedRatingData.isEmpty,
              let updatedRateData = Double(updatedRatingData),
              let movie = movie else {
            return
        }
        let updatedMovie = MovieModel(id: movie.id,movie: updatedMovieData, rating: updatedRateData)
        
        if let index = movieArr.firstIndex(where: { $0.id == movie.id }) {
            movieArr[index] = updatedMovie
        }
        
        CDManager().updateInCD(updatedMovie: updatedMovie)

        navigationController?.popViewController(animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
