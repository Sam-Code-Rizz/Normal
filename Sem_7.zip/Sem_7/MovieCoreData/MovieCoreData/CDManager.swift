//
//  CDManager.swift
//  MovieCoreData
//
//  Created by Sharma Aryan on 22/12/24.
//

import Foundation
import CoreData
import UIKit

class CDManager{
    func AddToCoreData(movie:MovieModel){
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else {return}
        
        let managedContext = delegate.persistentContainer.viewContext
        
        guard let movieEntity=NSEntityDescription.entity(forEntityName: "MovieEntity", in: managedContext) else {return}
        
        let movieData=NSManagedObject(entity: movieEntity, insertInto: managedContext)

        movieData.setValue(movie.id, forKey: "id")
        movieData.setValue(movie.movie, forKey: "movie")
        movieData.setValue(movie.rating, forKey: "rating")
        
        do{
            try managedContext.save()
            debugPrint("Data Added")
        }
        catch let err as NSError{
            print(err)
        }

    }
    
    func ReadCoreData() -> [MovieModel] {
        var MovieArr: [MovieModel] = []
        
        let delegate = UIApplication.shared.delegate as? AppDelegate

        let managedContext = delegate!.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "MovieEntity")
        
        do {
            let fetchedResults = try managedContext.fetch(fetchRequest)
            
            for data in fetchedResults as! [NSManagedObject] {
                if let movieData = data.value(forKey: "movie") as? String,
                   let Id = data.value(forKey: "id") as? UUID,
                   let ratingData = data.value(forKey: "rating") as? Double {
                    let movie = MovieModel(id: Id,movie: movieData, rating: ratingData)
                    MovieArr.append(movie)
                    print(movie)
                }
            }
        } catch let error as NSError {
            print("Failed to fetch data: \(error), \(error.userInfo)")
        }
        
        return MovieArr
        
    }
    
    func DeleteCoreData(movies: MovieModel) {
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else { return }
        
        let managedContext = delegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "MovieEntity")
        
        fetchRequest.predicate = NSPredicate(format: "id = %@", movies.id.uuidString)
        
        do {
            let fetchResults = try managedContext.fetch(fetchRequest)
            
            if let deleteObject = fetchResults.first as? NSManagedObject {
                managedContext.delete(deleteObject)
                try managedContext.save()
                debugPrint("Data deleted")
            } else {
                debugPrint("No matching object found for deletion")
            }
        } catch let err as NSError {
            debugPrint("Error during deletion: \(err)")
        }
    }
    
    func updateInCD(updatedMovie: MovieModel) {
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else { return }
        
        let managedContext = delegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "MovieEntity")
        
        fetchRequest.predicate = NSPredicate(format: "id = %@", updatedMovie.id.uuidString)
        
        do {
            let rawData = try managedContext.fetch(fetchRequest)
            
            if let objToUpdate = rawData.first as? NSManagedObject {

                objToUpdate.setValue(updatedMovie.movie, forKey: "movie")
                objToUpdate.setValue(updatedMovie.rating, forKey: "rating")
                
                try managedContext.save()
                print("Data updated successfully")
            } else {
                print("No matching object found for update")
            }
        } catch let error as NSError {
            print("Something went wrong while updating: \(error)")
        }
    }


    
}
