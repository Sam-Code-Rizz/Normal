//
//  MovieModel.swift
//  MovieCoreData
//
//  Created by Sharma Aryan on 22/12/24.
//

import Foundation

struct MovieModel: Codable {
    var id = UUID()
    var movie: String
    var rating: Double
}
