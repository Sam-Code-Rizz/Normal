//
//  TableCell.swift
//  MovieCoreData
//
//  Created by Sharma Aryan on 22/12/24.
//

import UIKit

class TableCell: UITableViewCell {
    @IBOutlet weak var rating: UILabel!
    @IBOutlet weak var movie: UILabel!
    @IBOutlet weak var id: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
