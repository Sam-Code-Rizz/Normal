//
//  CDManager.swift
//  CoreDataPractice
//
//  Created by Sharma Aryan on 12/12/24.
//

import Foundation
import CoreData
import UIKit

class CDManager
{
    static func AddtoCore(JokeData:JokeModel)
    {
        guard let delegate=UIApplication.shared.delegate as? AppDelegate else
        {
            return
        }
        let managedContext=delegate.persistentContainer.viewContext
        
        guard let jokeEntity=NSEntityDescription.entity(forEntityName: "Jokes", in: managedContext) else{return}
        let joke=NSManagedObject.init(entity: jokeEntity,insertInto: managedContext)
        joke.setValue(JokeData.id, forKey: "id")
        joke.setValue(JokeData.type, forKey: "type")
        joke.setValue(JokeData.setup, forKey: "setup")
        do{
            try managedContext.save()
            print("Data saved")
        }
        catch let err as NSError{
            print(err)
        }
    }
    
    // Read From CoreData
    
    static func ReadtoCore()->[JokeModel]
    {
        var jokeArr: [JokeModel] = []
        
        let delegate = UIApplication.shared.delegate as? AppDelegate

        let managedContext = delegate!.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Jokes")
        
        do {
            // Fetch results
            let fetchedResults = try managedContext.fetch(fetchRequest)
            
            // Iterate through fetched results and transform into JokeModel
            for data in fetchedResults as! [NSManagedObject] {
                if let jokeType = data.value(forKey: "type") as? String,
                   let jokeId = data.value(forKey: "id") as? UUID,
                   let jokeSetup = data.value(forKey: "setup") as? String {
                    let joke = JokeModel(id:jokeId, type: jokeType, setup: jokeSetup)
                    jokeArr.append(joke)
                    print(joke)
                }
            }
        } catch let err as NSError
        {
            print(err)
        }
        return jokeArr
    }
    
    func DeleteCoreData(jokes: JokeModel) {
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = delegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Jokes")
        fetchRequest.predicate = NSPredicate(format: "id = %@", jokes.id.uuidString)
        
        do {
            let fetchResults = try managedContext.fetch(fetchRequest)
            if let deleteObject = fetchResults.first as? NSManagedObject {
                managedContext.delete(deleteObject)
                try managedContext.save()
                debugPrint("Data deleted")
            } else {
                debugPrint("No matching object found for deletion")
            }
        } catch let err as NSError {
            debugPrint("Error during deletion: \(err)")
        }
    }
    
}
