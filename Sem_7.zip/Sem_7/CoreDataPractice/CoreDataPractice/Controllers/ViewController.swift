//
//  ViewController.swift
//  CoreDataPractice
//
//  Created by Sharma Aryan on 12/12/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var AddJoke: UIButton!
    @IBOutlet weak var jokeSetup: UITextField!
    @IBOutlet weak var joketype: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func FetchAction(_ sender: Any) {
        
    }
    
    @IBAction func AddAction(_ sender: Any) {
        
        let joketypeData=joketype.text!
        let jokesetupdata=jokeSetup.text!
        let joke=JokeModel(type: joketypeData, setup: jokesetupdata)
        CDManager.AddtoCore(JokeData: joke)
    }
    

}

