//
//  TableViewCell.swift
//  CoreDataPractice
//
//  Created by Sharma Aryan on 12/12/24.
//

import UIKit

class TableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var jokeSetup: UILabel!
    @IBOutlet weak var jokeType: UILabel!
    @IBOutlet weak var jokeid: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
