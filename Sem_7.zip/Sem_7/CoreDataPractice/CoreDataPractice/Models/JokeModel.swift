//
//  JokeModel.swift
//  CoreDataPractice
//
//  Created by Sharma Aryan on 12/12/24.
//

import Foundation

struct JokeModel: Codable {
    var id=UUID()
    var type:String
    var setup:String
}
