//
//  ViewController.swift
//  CoreDataExample
//
//  Created by Sharma Aryan on 09/12/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var SubmitBtn: UIButton!
   
    @IBOutlet weak var JokeSetup: UITextField!
    @IBOutlet weak var JokeType: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func SubmitAction(_ sender: Any) {
        var jokeTypeData=JokeType.text!
        var jokeSetupData=JokeSetup.text!
        let joke=JokeModel(type: jokeTypeData, setup: jokeSetupData)
        CDManager().AddToCoreData(jokes: joke)
//        CDManager().ReadCoreData()
    }
    
}

