//
//  CDManager.swift
//  CoreDataExample
//
//  Created by Sharma Aryan on 09/12/24.
//

import Foundation
import CoreData
import UIKit

class CDManager{
    
    func AddToCoreData(jokes:JokeModel){
        
        guard let delegate=UIApplication.shared.delegate as? AppDelegate else {return}
        
        let managedContext=delegate.persistentContainer.viewContext
        
        guard let jokeEntity=NSEntityDescription.entity(forEntityName: "Jokes", in: managedContext) else {return}
        
        let joke=NSManagedObject(entity: jokeEntity, insertInto: managedContext)

        joke.setValue(jokes.id, forKey: "id")
        joke.setValue(jokes.type, forKey: "type")
        joke.setValue(jokes.setup, forKey: "setup")
        
        do{
            try managedContext.save()
            debugPrint("Data Added")
        }
        catch let err as NSError
        {
            debugPrint("Error \(err)")
        }
    }
   	
    func ReadCoreData() -> [JokeModel] {
        var jokeArr: [JokeModel] = [] // Initialize an empty array to store the results

        // Ensure AppDelegate is correctly accessed
        let delegate = UIApplication.shared.delegate as? AppDelegate

        let managedContext = delegate!.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Jokes")
        
        do {
            // Fetch results
            let fetchedResults = try managedContext.fetch(fetchRequest)
            
            // Iterate through fetched results and transform into JokeModel
            for data in fetchedResults as! [NSManagedObject] {
                if let jokeType = data.value(forKey: "type") as? String,
                   let jokeId = data.value(forKey: "id") as? UUID,
                   let jokeSetup = data.value(forKey: "setup") as? String {
                    let joke = JokeModel(id:jokeId, type: jokeType, setup: jokeSetup)
                    jokeArr.append(joke)
                    print(joke)
                }
            }
        } catch let error as NSError {
            print("Failed to fetch data: \(error), \(error.userInfo)")
        }
        
        return jokeArr
    }
    
    func DeleteCoreData(jokes: JokeModel) {
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = delegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Jokes")
        fetchRequest.predicate = NSPredicate(format: "id = %@", jokes.id.uuidString)
        
        do {
            let fetchResults = try managedContext.fetch(fetchRequest)
            if let deleteObject = fetchResults.first as? NSManagedObject {
                managedContext.delete(deleteObject)
                try managedContext.save()
                debugPrint("Data deleted")
            } else {
                debugPrint("No matching object found for deletion")
            }
        } catch let err as NSError {
            debugPrint("Error during deletion: \(err)")
        }
    }

    func updateInCD(updatedJoke: JokeModel) {
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else { return }
        
        let managedContext = delegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Jokes")
        
        // Use predicate to match the joke by its id
        fetchRequest.predicate = NSPredicate(format: "id = %@", updatedJoke.id.uuidString)
        
        do {
            // Fetch the object to update
            let rawData = try managedContext.fetch(fetchRequest)
            
            if let objToUpdate = rawData.first as? NSManagedObject {
                // Update the properties of the object
                objToUpdate.setValue(updatedJoke.type, forKey: "type")
                objToUpdate.setValue(updatedJoke.setup, forKey: "setup")
                
                // Save the context
                try managedContext.save()
                print("Data updated successfully")
            } else {
                print("No matching object found for update")
            }
        } catch let error as NSError {
            print("Something went wrong while updating: \(error)")
        }
    }

    
    
}
