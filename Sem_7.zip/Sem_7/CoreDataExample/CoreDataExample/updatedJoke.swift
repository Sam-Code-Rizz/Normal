import UIKit

class updatedJoke: UIViewController {
    
    @IBOutlet weak var UpdateBtn: UIButton!
    @IBOutlet weak var UpdatedJokeSetup: UITextField!
    @IBOutlet weak var UpdatedJokeType: UITextField!
    
    var joke: JokeModel? // The passed joke object
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Pre-fill text fields with the current joke data
        if let joke = joke {
            UpdatedJokeSetup.text = joke.setup
            UpdatedJokeType.text = joke.type
        }
    }
    
    @IBAction func UpdateAction(_ sender: Any) {
        // Ensure that both fields are not empty
        guard let updatedSetup = UpdatedJokeSetup.text, !updatedSetup.isEmpty,
              let updatedType = UpdatedJokeType.text, !updatedType.isEmpty,
              let joke = joke else {
            return
        }
        
        // Create updated joke object
        let updatedJoke = JokeModel(id: joke.id, type: updatedType, setup: updatedSetup)
        
        // Update the joke in the global array (jokeArr)
        if let index = jokeArr.firstIndex(where: { $0.id == joke.id }) {
            jokeArr[index] = updatedJoke
        }
        
        // Update Core Data
        CDManager().updateInCD(updatedJoke: updatedJoke)
        
        // Go back to the previous screen
        navigationController?.popViewController(animated: true)
    }
}
