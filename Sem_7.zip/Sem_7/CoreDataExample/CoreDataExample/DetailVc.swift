//
//  DetailVc.swift
//  CoreDataExample
//
//  Created by Sharma Aryan on 09/12/24.
//

import UIKit

var jokeArr:[JokeModel]=[]

class DetailVc: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        jokeArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "TableCell", for: indexPath) as! TableCell
        let joke=jokeArr[indexPath.row]
        cell.JokeId.text=joke.id.uuidString
        cell.JokeType.text=joke.type
        cell.JokeSetup.text=joke.setup
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        200
    }
    

    @IBOutlet weak var Table: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        Table.delegate=self
        Table.dataSource=self
        Table.register(UINib(nibName: "TableCell", bundle: nil), forCellReuseIdentifier: "TableCell")
        jokeArr=CDManager().ReadCoreData()
        Table.reloadData()
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { _, _, completionHandler in
            // Remove the joke from Core Data first
            let joke = jokeArr[indexPath.row]
            CDManager().DeleteCoreData(jokes: joke)
            
            // Remove the joke from the data array
            jokeArr.remove(at: indexPath.row)
            
            // Update the table view
            tableView.performBatchUpdates {
                tableView.deleteRows(at: [indexPath], with: .automatic)
            } completion: { _ in
                completionHandler(true)
            }
        }
        let updateAction = UIContextualAction(style: .normal, title: "Edit") { _, _, completionHandler in
                    // Perform segue to UpdateJokeViewController
                    self.performSegue(withIdentifier: "updatejoke", sender: indexPath)
                    completionHandler(true)
            
                }
                updateAction.backgroundColor = .systemBlue
        
                
        
        return UISwipeActionsConfiguration(actions: [deleteAction,updateAction])
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "updatejoke",
           let destination = segue.destination as? updatedJoke,
           let indexPath = sender as? IndexPath {
            // Pass the selected joke to updatedJoke
            destination.joke = jokeArr[indexPath.row]
        }
    }


    override func viewDidAppear(_ animated: Bool) {
        Table.reloadData()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
