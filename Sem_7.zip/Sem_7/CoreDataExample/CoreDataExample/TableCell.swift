//
//  TableCell.swift
//  CoreDataExample
//
//  Created by Sharma Aryan on 09/12/24.
//

import UIKit

class TableCell: UITableViewCell {

    @IBOutlet weak var JokeSetup: UILabel!
    @IBOutlet weak var JokeType: UILabel!
    @IBOutlet weak var JokeId: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        JokeSetup.text="Hell"
        JokeType.text="World"
        JokeId.text="2"
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
