//
//  JokeModel.swift
//  CoreDataExample
//
//  Created by Sharma Aryan on 09/12/24.
//

import Foundation
struct JokeModel:Codable
{
    var id = UUID()
    var type:String
    var setup:String
}
