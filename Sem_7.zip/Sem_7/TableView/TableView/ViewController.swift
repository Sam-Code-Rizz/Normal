//
//  ViewController.swift
//  TableView
//
//  Created by Sharma Aryan on 15/10/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "TableCell", for: indexPath) as! TableCell
        cell.FirstLabel.text="Hello World";
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        200
    }
    @IBOutlet weak var Table: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Table.delegate=self
        Table.dataSource=self
        Table.register(UINib(nibName: "TableCell", bundle: nil), forCellReuseIdentifier: "TableCell")
        // Do any additional setup after loading the view.
    }


}

