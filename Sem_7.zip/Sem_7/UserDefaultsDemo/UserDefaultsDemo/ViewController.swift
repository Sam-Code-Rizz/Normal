//
//  ViewController.swift
//  UserDefaultsDemo
//
//  Created by Sharma Aryan on 22/12/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var submit: UIButton!
    
    @IBOutlet weak var name: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func saveToUsrDefault(key: String, value: Any) {
            let defaults = UserDefaults.standard
            defaults.set(value, forKey: key)
        }


    @IBAction func submitAction(_ sender: Any) {
        saveToUsrDefault(key: "name", value: name.text!)
        performSegue(withIdentifier: "showData", sender: self)
    }
    
}

