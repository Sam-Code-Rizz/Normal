//
//  ShowVC.swift
//  UserDefaultsDemo
//
//  Created by Sharma Aryan on 22/12/24.
//

import UIKit

class ShowVC: UIViewController {

    @IBOutlet weak var nameData: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        nameData.text = readFromUsrDefault(key: "name")
        // Do any additional setup after loading the view.
    }
    
    func readFromUsrDefault(key: String) -> String {
            
            let defaults = UserDefaults.standard
            guard let retrivedData = defaults.string(forKey: key) else { return "" }
            return retrivedData
            
        }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
