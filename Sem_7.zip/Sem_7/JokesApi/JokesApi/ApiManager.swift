//
//  ApiManager.swift
//  JokesApi
//
//  Created by Sharma Aryan on 16/10/24.
//

import Foundation
import Alamofire

class ApiManager{
    let urlstr = "https://jsonplaceholder.typicode.com/users"
    
    func fetchJokes(CompletionHandler: @escaping(Result<[UserModel],Error>)->Void){
        
        AF.request(urlstr).responseDecodable(of: [UserModel].self) { response in
            
            switch response.result {
            case .success(let data):
                CompletionHandler(.success(data))
                
            case .failure(let error):
                CompletionHandler(.failure(error))
            }
        }
    }
}
