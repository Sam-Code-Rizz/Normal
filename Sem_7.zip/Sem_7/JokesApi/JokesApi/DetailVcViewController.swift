//
//  DetailVcViewController.swift
//  JokesApi
//
//  Created by Sharma Aryan on 16/10/24.
//

import UIKit

class DetailVcViewController: UIViewController {
    @IBOutlet weak var Id: UILabel!
    @IBOutlet weak var Name: UILabel!
    @IBOutlet weak var Address: UILabel!
    @IBOutlet weak var Lat: UILabel!
    var CurrentUser:UserModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Id.text=String(CurrentUser.id)
        Name.text=CurrentUser.name
        Address.text=CurrentUser.address?.street
        Lat.text=CurrentUser.address?.geo?.lat
    
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
