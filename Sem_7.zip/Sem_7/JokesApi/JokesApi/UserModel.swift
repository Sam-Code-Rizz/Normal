//
//  UserModel.swift
//  JokesApi
//
//  Created by Sharma Aryan on 16/10/24.
//

import Foundation
struct Geo:Codable
{
    let lat:String
}
struct Address:Codable
{
    let street:String
    let geo:Geo?
}
struct UserModel:Codable{
    let id: Int
    let name:String
    let address:Address?
}
