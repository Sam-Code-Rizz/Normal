//
//  ViewController.swift
//  JokesApi
//
//  Created by Sharma Aryan on 16/10/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var LoadingIndicator: UIActivityIndicatorView!
    var User:[UserModel]=[]
    private var selectedUser:UserModel!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return User.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "TableCell", for: indexPath) as! TableCell
        cell.Id.text=String(User[indexPath.row].id)
        cell.Name.text=User[indexPath.row].name
        cell.street.text=User[indexPath.row].address?.street
        cell.lat.text=User[indexPath.row].address?.geo?.lat
        return cell
    
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        400
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedUser=User[indexPath.row]
        performSegue(withIdentifier: "GoToNext", sender: self)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier=="GoToNext"{
            if let DetailVc=segue.destination as? DetailVcViewController
            {
                DetailVc.CurrentUser=selectedUser
            }
        }
    }

    @IBOutlet weak var Table: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        Table.delegate=self
        Table.dataSource=self
        Table.register(UINib(nibName: "TableCell", bundle: nil), forCellReuseIdentifier: "TableCell")
        ApiCall()
        // Do any additional setup after loading the view.
    }
    func ApiCall(){
        LoadingIndicator.startAnimating()
        ApiManager().fetchJokes{
            response in switch response{
            case .success(let data):
                
                debugPrint("Success")
                self.User.append(contentsOf: data)
                self.Table.reloadData()
                self.LoadingIndicator.stopAnimating()
                self.LoadingIndicator.isHidden=true
            case .failure(let error):
                
                debugPrint("Error \(error)")
            }
        }
    }
    func StartAnimation(){
        DispatchQueue.main.async {
            self.LoadingIndicator.startAnimating()
            self.LoadingIndicator.isHidden=false
        }
    }
    func StopAnimation(){
        DispatchQueue.main.async {
            self.LoadingIndicator.stopAnimating()
            self.LoadingIndicator.isHidden=true
        }
    
    }
}

