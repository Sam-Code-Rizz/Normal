//
//  JokeModel.swift
//  JokesApi
//
//  Created by Sharma Aryan on 16/10/24.
//

import Foundation

struct JokeModel: Codable {
    let Id: Int
    let Types: String
    let Setup: String
    let Punchline: String
}
