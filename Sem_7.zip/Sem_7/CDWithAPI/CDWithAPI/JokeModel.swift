//
//  JokeModel.swift
//  CDWithAPI
//
//  Created by Sharma Aryan on 12/12/24.
//

import Foundation

struct JokeModel: Codable {
    let id: Int
    let type: String
    let setup: String
    let punchline: String
}
