//
//  ViewController.swift
//  CDWithAPI
//
//  Created by Sharma Aryan on 12/12/24.
//

import UIKit
import Alamofire
import CoreData

class ViewController: UIViewController {

//    @IBOutlet weak var savedTableView: UITableView!
//    @IBOutlet weak var apiTableView: UITableView!
//    @IBOutlet weak var segmentedControl: UISegmentedControl!

    // MARK: - UI Elements
    @IBOutlet weak var segmentedControl: UISegmentedControl! = {
        let control = UISegmentedControl(items: ["API Jokes", "Saved Jokes"])
        control.selectedSegmentIndex = 0
        control.translatesAutoresizingMaskIntoConstraints = false
        return control
    }()
    
    @IBOutlet weak var apiTableView: UITableView! = {
        let tableView = UITableView()
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "jokeCell")
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.isHidden = false // Show this by default
        return tableView
    }()
    
    @IBOutlet weak var savedTableView: UITableView! = {
        let tableView = UITableView()
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "jokeCell")
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.isHidden = true // Hidden by default
        return tableView
    }()
    
    // MARK: - Data
    private var apiJokes: [JokeModel] = []
    private var savedJokes: [JokeModel] = []
    private let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    // MARK: - View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        // Add subviews
        view.addSubview(segmentedControl)
        view.addSubview(apiTableView)
        view.addSubview(savedTableView)
        
        // Setup constraints
        setupConstraints()
        
        // Set up actions and delegates
        segmentedControl.addTarget(self, action: #selector(segmentChanged), for: .valueChanged)
        apiTableView.dataSource = self
        apiTableView.delegate = self
        savedTableView.dataSource = self
        savedTableView.delegate = self
        
        // Register the XIB for the table view
        let nib = UINib(nibName: "JokeCell", bundle: nil)
        apiTableView.register(nib, forCellReuseIdentifier: "jokeCell")
        savedTableView.register(nib, forCellReuseIdentifier: "jokeCell")
        
        // Load initial data
        loadAPIJokes()
    }
    
    // MARK: - Layout
    private func setupConstraints() {
        NSLayoutConstraint.activate([
            // Segmented Control
            segmentedControl.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            segmentedControl.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
            segmentedControl.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10),
            
            // API TableView
            apiTableView.topAnchor.constraint(equalTo: segmentedControl.bottomAnchor, constant: 10),
            apiTableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            apiTableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            apiTableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            // Saved TableView
            savedTableView.topAnchor.constraint(equalTo: segmentedControl.bottomAnchor, constant: 10),
            savedTableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            savedTableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            savedTableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    // MARK: - Segmented Control Action
    @objc private func segmentChanged() {
        if segmentedControl.selectedSegmentIndex == 0 {
            apiTableView.isHidden = false
            savedTableView.isHidden = true
        } else {
            apiTableView.isHidden = true
            savedTableView.isHidden = false
            loadSavedJokes()
        }
    }

    // MARK: - Data Loading
    private func loadAPIJokes() {
        ApiManager.shared.fetchJokes { [weak self] result in
            switch result {
            case .success(let jokes):
                self?.apiJokes = jokes
                DispatchQueue.main.async {
                    self?.apiTableView.reloadData()
                }
                // Save jokes to Core Data for demonstration purposes
                self?.saveJokesToCoreData(jokes: jokes)
            case .failure(let error):
                print("Error fetching jokes: \(error)")
            }
        }
    }
    
    private func loadSavedJokes() {
        savedJokes = CDManager.shared.fetchAllJokes()
        savedTableView.reloadData()
    }

    // MARK: - Save to Core Data
    private func saveJokesToCoreData(jokes: [JokeModel]) {
        CDManager.shared.saveJokes(jokes)
    }
}

// MARK: - UITableViewDataSource & UITableViewDelegate
extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == apiTableView {
            return apiJokes.count
        } else {
            return savedJokes.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Dequeue the cell
        let cell = tableView.dequeueReusableCell(withIdentifier: "jokeCell", for: indexPath) as! JokeCell

        // Get the joke (either from API or saved)
        let joke: JokeModel
        if tableView == apiTableView {
            joke = apiJokes[indexPath.row]
        } else {
            joke = savedJokes[indexPath.row]
        }

        // Configure the cell with the joke data
        cell.configure(with: joke)

        return cell
    }

    
    // Enable swipe-to-delete for the saved jokes table view
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if tableView == savedTableView && editingStyle == .delete {
            let jokeToDelete = savedJokes[indexPath.row]
            CDManager.shared.deleteJoke(id: jokeToDelete.id)
            savedJokes.remove(at: indexPath.row)
            savedTableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
}


