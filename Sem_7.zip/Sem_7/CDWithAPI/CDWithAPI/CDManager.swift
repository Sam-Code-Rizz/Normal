//
//  CDManager.swift
//  CDWithAPI
//
//  Created by Sharma Aryan on 12/12/24.
//

import Foundation
import CoreData
import UIKit

class CDManager {

    static let shared = CDManager() // Singleton instance
    
    private let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    private init() {} // Prevent direct instantiation
    
    // MARK: - Create (Save Jokes to Core Data)
    func saveJokes(_ jokes: [JokeModel]) {
        jokes.forEach { joke in
            let jokeEntity = NSEntityDescription.insertNewObject(forEntityName: "JokeEntity", into: context)
            jokeEntity.setValue(joke.id, forKey: "id")
            jokeEntity.setValue(joke.type, forKey: "type")
            jokeEntity.setValue(joke.setup, forKey: "setup")
            jokeEntity.setValue(joke.punchline, forKey: "punchline")
        }
        saveContext()
    }
    
    // MARK: - Read (Fetch Jokes from Core Data)
    func fetchAllJokes() -> [JokeModel] {
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "JokeEntity")
        do {
            let jokeEntities = try context.fetch(fetchRequest)
            return jokeEntities.map { jokeEntity in
                JokeModel(
                    id: jokeEntity.value(forKey: "id") as! Int,
                    type: jokeEntity.value(forKey: "type") as! String,
                    setup: jokeEntity.value(forKey: "setup") as! String,
                    punchline: jokeEntity.value(forKey: "punchline") as! String
                )
            }
        } catch {
            print("Failed to fetch jokes: \(error.localizedDescription)")
            return []
        }
    }
    
    // MARK: - Update (Modify a Specific Joke)
    func updateJoke(id: Int, newSetup: String, newPunchline: String) {
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "JokeEntity")
        fetchRequest.predicate = NSPredicate(format: "id == %d", id)
        do {
            let jokeEntities = try context.fetch(fetchRequest)
            if let jokeEntity = jokeEntities.first {
                jokeEntity.setValue(newSetup, forKey: "setup")
                jokeEntity.setValue(newPunchline, forKey: "punchline")
                saveContext()
            } else {
                print("Joke with id \(id) not found.")
            }
        } catch {
            print("Failed to update joke: \(error.localizedDescription)")
        }
    }
    
    // MARK: - Delete (Remove a Specific Joke)
    func deleteJoke(id: Int) {
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "JokeEntity")
        fetchRequest.predicate = NSPredicate(format: "id == %d", id)
        do {
            let jokeEntities = try context.fetch(fetchRequest)
            if let jokeEntity = jokeEntities.first {
                context.delete(jokeEntity)
                saveContext()
            } else {
                print("Joke with id \(id) not found.")
            }
        } catch {
            print("Failed to delete joke: \(error.localizedDescription)")
        }
    }
    
    // MARK: - Delete All Jokes
    func deleteAllJokes() {
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "JokeEntity")
        do {
            let jokeEntities = try context.fetch(fetchRequest)
            jokeEntities.forEach { context.delete($0) }
            saveContext()
        } catch {
            print("Failed to delete all jokes: \(error.localizedDescription)")
        }
    }
    
    // MARK: - Save Context
    private func saveContext() {
        if context.hasChanges {
            do {
                try context.save()
                print("Context saved successfully.")
            } catch {
                print("Failed to save context: \(error.localizedDescription)")
            }
        }
    }
}
