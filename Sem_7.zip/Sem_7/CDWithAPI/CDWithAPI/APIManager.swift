//
//  APIManager.swift
//  CDWithAPI
//
//  Created by Sharma Aryan on 12/12/24.
//

import Foundation

import Alamofire
import CoreData
import UIKit

//class APIManager {
//    static let shared = JokesManager()
//
//    func fetchJokes(completion: @escaping (Result<[Joke], Error>) -> Void) {
//        let url = "https://official-joke-api.appspot.com/jokes/random/25"
//
//        AF.request(url).validate().responseDecodable(of: [Joke].self) { response in
//            switch response.result {
//            case .success(let jokes):
//                completion(.success(jokes))
//            case .failure(let error):
//                completion(.failure(error))
//            }
//        }
//    }
//}

class ApiManager {
    static let shared = ApiManager()
    
    let urlstr = "https://official-joke-api.appspot.com/jokes/random/25"
    
    func fetchJokes(completionHandler: @escaping(Result<[JokeModel], Error>) -> Void) {
        
        AF.request(urlstr).responseDecodable(of: [JokeModel].self) { response in
            
            switch response.result {
                
            case .success(let data):
                completionHandler(.success(data))
                
            case .failure(let error):
                completionHandler(.failure(error))
            }
            
        }
    }
}
