//
//  JokeCell.swift
//  CDWithAPI
//
//  Created by Sharma Aryan on 13/12/24.
//

import UIKit

class JokeCell: UITableViewCell {

    @IBOutlet weak var setupLabel: UILabel! = {
        let label = UILabel()
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    @IBOutlet weak var punchlineLabel: UILabel! = {
        let label = UILabel()
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 14, weight: .light)
        label.textColor = .gray
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    // MARK: - Initialization
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubview(setupLabel)
        contentView.addSubview(punchlineLabel)

        // Setup Constraints
        NSLayoutConstraint.activate([
            // Setup Label Constraints
            setupLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            setupLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 15),
            setupLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -15),

            // Punchline Label Constraints
            punchlineLabel.topAnchor.constraint(equalTo: setupLabel.bottomAnchor, constant: 8),
            punchlineLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 15),
            punchlineLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -15),
            punchlineLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10)
        ])
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        // Load the XIB
        if let contentView = Bundle.main.loadNibNamed("JokeCell", owner: self, options: nil)?.first as? UIView {
            contentView.frame = self.contentView.bounds
            self.contentView.addSubview(contentView)
        }
    }

    // MARK: - Configure Cell
    func configure(with joke: JokeModel) {
        setupLabel.text = joke.setup
        punchlineLabel.text = joke.punchline
    }
}
