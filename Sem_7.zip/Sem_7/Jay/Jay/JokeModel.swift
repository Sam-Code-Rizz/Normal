//
//  JokeModel.swift
//  Jay
//
//  Created by Sharma Aryan on 16/10/24.
//

import Foundation

struct JokeModel: Codable {
    let id: Int
    let type: String
    let setup: String
    let punchline: String
}
