//
//  ApiManager.swift
//  Jay
//
//  Created by Sharma Aryan on 16/10/24.
//

import Foundation
import Alamofire

class ApiManager{
    let strurl="https://official-joke-api.appspot.com/jokes/random/25"
    
    func JokesApi(completionHandler: @escaping(Result<[JokeModel],Error>)->Void){
        AF.request(strurl).responseDecodable(of: [JokeModel].self) { response in
            switch response.result {
            case .success(let data):
                completionHandler(.success(data))
            case .failure(let error):
                completionHandler(.failure(error))
            }
        }
    }   
}
