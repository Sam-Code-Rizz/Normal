//
//  ClassVsStructApp.swift
//  ClassVsStruct
//
//  Created by Sharma Aryan on 07/10/24.
//

import SwiftUI

@main
struct ClassVsStructApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
