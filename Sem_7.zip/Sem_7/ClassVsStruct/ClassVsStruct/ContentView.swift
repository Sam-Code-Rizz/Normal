//
//  ContentView.swift
//  ClassVsStruct
//
//  Created by Sharma Aryan on 07/10/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Text("Hello, world!")
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

//L2P00RYGR
//TH 11
//31K, 34Q,14W

