//
//  ViewController.swift
//  ClosuresDemo
//
//  Created by Sharma Aryan on 19/12/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchData{message in
            print(message)
        }
        // Do any additional setup after loading the view.
    }

    func fetchData(completion: (String)-> Void){
        let fetch = "Hello, Jay."
        
        completion(fetch)
    }
}

