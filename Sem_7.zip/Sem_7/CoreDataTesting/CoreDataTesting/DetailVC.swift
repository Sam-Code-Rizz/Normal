//
//  DetailVC.swift
//  CoreDataTesting
//
//  Created by Sharma Aryan on 12/12/24.
//

import UIKit

var userArr:[UserModel]=[]

class DetailVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        userArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "TableCell", for: indexPath) as! TableCell
        let user=userArr[indexPath.row]
        cell.userId.text=user.id.uuidString
        cell.userName.text=user.name
        cell.userGender.text=user.gender
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        250
    }
    

    @IBOutlet weak var Table: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Table.delegate=self
        Table.dataSource=self
        Table.register(UINib(nibName: "TableCell", bundle: nil), forCellReuseIdentifier: "TableCell")
        userArr=CDManager().ReadCoreData()
        Table.reloadData()
        
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { _, _, completionHandler in

            let user = userArr[indexPath.row]
            CDManager().DeleteCoreData(users: user)
            
            userArr.remove(at: indexPath.row)
            
            // Update the table view
            tableView.performBatchUpdates {
                tableView.deleteRows(at: [indexPath], with: .automatic)
            } completion: { _ in
                completionHandler(true)
            }
        }
        
        let updateAction = UIContextualAction(style: .normal, title: "Edit") { _, _, completionHandler in
                    
                    self.performSegue(withIdentifier: "updatedUser", sender: indexPath)
                    completionHandler(true)
            
                }
                updateAction.backgroundColor = .systemBlue
        
                
        
        return UISwipeActionsConfiguration(actions: [deleteAction,updateAction])
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "updatedUser",
           let destination = segue.destination as? updatedUser,
           let indexPath = sender as? IndexPath {
            destination.user = userArr[indexPath.row]
        }
    }


    override func viewDidAppear(_ animated: Bool) {
        Table.reloadData()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
