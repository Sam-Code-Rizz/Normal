//
//  TableCell.swift
//  CoreDataTesting
//
//  Created by Sharma Aryan on 12/12/24.
//

import UIKit

class TableCell: UITableViewCell {

    @IBOutlet weak var userGender: UILabel!
    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var userId: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        userGender.text="Hell"
        userName.text="World"
        userId.text="2"
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
