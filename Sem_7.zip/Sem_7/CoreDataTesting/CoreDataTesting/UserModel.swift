//
//  UserModel.swift
//  CoreDataTesting
//
//  Created by Sharma Aryan on 12/12/24.
//

import Foundation

struct UserModel: Codable{
    var id=UUID()
    var name:String
    var gender:String
}
