//
//  CDManager.swift
//  CoreDataTesting
//
//  Created by Sharma Aryan on 12/12/24.
//

import Foundation
import CoreData
import UIKit

class CDManager{
    func AddToCoreData(Users:UserModel){
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else {return}
        
        let managedContext = delegate.persistentContainer.viewContext
        
        guard let userEntity=NSEntityDescription.entity(forEntityName: "Users", in: managedContext) else {return}
        
        let user=NSManagedObject(entity: userEntity, insertInto: managedContext)

        user.setValue(Users.id, forKey: "id")
        user.setValue(Users.name, forKey: "name")
        user.setValue(Users.gender, forKey: "gender")
        
        do{
            try managedContext.save()
            debugPrint("Data Added")
        }
        catch let err as NSError{
            print(err)
        }

    }
    
    func ReadCoreData() -> [UserModel] {
        var UserArr: [UserModel] = []
        
        let delegate = UIApplication.shared.delegate as? AppDelegate

        let managedContext = delegate!.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        
        do {
            let fetchedResults = try managedContext.fetch(fetchRequest)
            
            for data in fetchedResults as! [NSManagedObject] {
                if let userName = data.value(forKey: "name") as? String,
                   let userId = data.value(forKey: "id") as? UUID,
                   let userGender = data.value(forKey: "gender") as? String {
                    let user = UserModel(id:userId, name: userName, gender: userGender)
                    UserArr.append(user)
                    print(user)
                }
            }
        } catch let error as NSError {
            print("Failed to fetch data: \(error), \(error.userInfo)")
        }
        
        return UserArr
        
    }
    
    func DeleteCoreData(users: UserModel) {
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else { return }
        
        let managedContext = delegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        
        fetchRequest.predicate = NSPredicate(format: "id = %@", users.id.uuidString)
        
        do {
            let fetchResults = try managedContext.fetch(fetchRequest)
            
            if let deleteObject = fetchResults.first as? NSManagedObject {
                managedContext.delete(deleteObject)
                try managedContext.save()
                debugPrint("Data deleted")
            } else {
                debugPrint("No matching object found for deletion")
            }
        } catch let err as NSError {
            debugPrint("Error during deletion: \(err)")
        }
    }
    
    func updateInCD(updatedUser: UserModel) {
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else { return }
        
        let managedContext = delegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        
        // Use predicate to match the joke by its id
        fetchRequest.predicate = NSPredicate(format: "id = %@", updatedUser.id.uuidString)
        
        do {
            // Fetch the object to update
            let rawData = try managedContext.fetch(fetchRequest)
            
            if let objToUpdate = rawData.first as? NSManagedObject {
                // Update the properties of the object
                objToUpdate.setValue(updatedUser.name, forKey: "name")
                objToUpdate.setValue(updatedUser.gender, forKey: "gender")
                
                // Save the context
                try managedContext.save()
                print("Data updated successfully")
            } else {
                print("No matching object found for update")
            }
        } catch let error as NSError {
            print("Something went wrong while updating: \(error)")
        }
    }


    
}
