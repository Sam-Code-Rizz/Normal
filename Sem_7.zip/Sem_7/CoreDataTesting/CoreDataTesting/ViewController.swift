//
//  ViewController.swift
//  CoreDataTesting
//
//  Created by Sharma Aryan on 12/12/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var fetch: UIButton!
    @IBOutlet weak var submit: UIButton!
    @IBOutlet weak var gender: UITextField!
    @IBOutlet weak var name: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func fetchAction(_ sender: Any) {
        
    }
    
    @IBAction func submitAction(_ sender: Any) {
        let userNameData=name.text!
        let userGenderData=gender.text!
        let user=UserModel(name: userNameData, gender: userGenderData)
        CDManager().AddToCoreData(Users: user)
//          CDManager().ReadCoreData()
    }
}

