//
//  updatedUser.swift
//  CoreDataTesting
//
//  Created by Sharma Aryan on 12/12/24.
//

import UIKit

class updatedUser: UIViewController {

    @IBOutlet weak var UpdateBtn: UIButton!
    @IBOutlet weak var UpdatedUserGender: UITextField!
    @IBOutlet weak var UpdatedUserName: UITextField!
    
    var user: UserModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let user = user {
            UpdatedUserName.text = user.name
            UpdatedUserGender.text = user.gender
        }

    }
    
    @IBAction func UpdateAction(_ sender: Any) {
        // Ensure that both fields are not empty
        guard let updatedName = UpdatedUserName.text, !updatedName.isEmpty,
              let updatedGender = UpdatedUserGender.text, !updatedGender.isEmpty,
              let user = user else {
            return
        }
        
        // Create updated joke object
        let updatedUser = UserModel(id: user.id, name: updatedName, gender: updatedGender)
        
        // Update the joke in the global array (jokeArr)
        if let index = userArr.firstIndex(where: { $0.id == user.id }) {
            userArr[index] = updatedUser
        }
        
        // Update Core Data
        CDManager().updateInCD(updatedUser: updatedUser)
        // Go back to the previous screen
        navigationController?.popViewController(animated: true)
    }
    
}
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


