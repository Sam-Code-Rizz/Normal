//
//  MovieModel.swift
//  MoviesSegment
//
//  Created by Sharma Aryan on 22/12/24.
//

import Foundation

struct MovieModel:Codable {
    var id: Int64
    var movie: String
    var rating: Double
    var image: String
    var imdb_url: String
}
