//
//  ViewController.swift
//  MoviesSegment
//
//  Created by Sharma Aryan on 22/12/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
                self.CoreData = CDManager().ReadCD()
        self.reloadTable()
    }
    
    @IBOutlet weak var loading: UIActivityIndicatorView!
    var CoreData: [MovieModel] = []
    var MovieApi: [MovieModel] = []
    @IBOutlet weak var CDTable: UITableView!
    @IBOutlet weak var apiTable: UITableView!
    @IBOutlet weak var segment: UISegmentedControl!
    var selectedMovie: MovieModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.CDTable.delegate = self
        self.CDTable.dataSource = self
        self.CDTable.register(UINib(nibName: "TableCell", bundle: nil), forCellReuseIdentifier: "TableCell")
        
        self.apiTable.delegate = self
        self.apiTable.dataSource = self
        self.apiTable.register(UINib(nibName: "TableCell", bundle: nil), forCellReuseIdentifier: "TableCell")
        
        CDTable.isHidden = true
        self.CoreData = CDManager().ReadCD()
        
        fetchAF {
            response in
            switch response {
                
            case .success(let data):
                self.MovieApi.append(contentsOf: data)
                self.reloadTable()
                self.loading.isHidden = true
                
                
            case .failure(let error):
                debugPrint(error)
            }
        }
        self.reloadTable()
        
        segment.selectedSegmentIndex = 0
        // Do any additional setup after loading the view.
    }


    @IBAction func segmentBtn(_ sender: Any) {
        if segment.selectedSegmentIndex == 0 {
            apiTable.isHidden = false
            CDTable.isHidden = true
            reloadTable()
        }
        else {
            apiTable.isHidden = true
            CDTable.isHidden = false
            self.CoreData = CDManager().ReadCD()
            reloadTable()
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableView == apiTable ? MovieApi.count : CoreData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableCell", for: indexPath) as! TableCell
        if tableView == apiTable {
            cell.id.text = "\(MovieApi[indexPath.row].id)"
            cell.movie.text = MovieApi[indexPath.row].movie
            cell.rating.text = "\(MovieApi[indexPath.row].rating)"
            cell.movie_image.text = MovieApi[indexPath.row].image
            cell.imdb_url.text = MovieApi[indexPath.row].imdb_url
        }
        else {
            cell.id.text = "\(CoreData[indexPath.row].id)"
            cell.movie.text = CoreData[indexPath.row].movie
            cell.rating.text = "\(CoreData[indexPath.row].rating)"
            cell.movie_image.text = CoreData[indexPath.row].image
            cell.imdb_url.text = CoreData[indexPath.row].imdb_url
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 400
    }
    
    func reloadTable() {
        DispatchQueue.main.async {
            if self.segment.selectedSegmentIndex == 0 {
                self.apiTable.reloadData()
            } else if self.segment.selectedSegmentIndex == 1{
                self.CDTable.reloadData()
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == apiTable {
            CDManager().AddCD(movieData: MovieApi[indexPath.row])
            debugPrint("Print Inside APITable")
        }
    }
    
    func deleteFromArr(position: Int) {
        CoreData.remove(at: position)
        DispatchQueue.main.async {
            self.CDTable.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        if tableView == CDTable {
            let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { [self] _, _, completionHandler in
                
                let movie = self.CoreData[indexPath.row]
                CDManager().DeleteCD(movieDelete: movie)
                
                deleteFromArr(position: indexPath.row)
                
                tableView.performBatchUpdates {
                    tableView.deleteRows(at: [indexPath], with: .automatic)
                } completion: { _ in
                    completionHandler(true)
                }
            }
            deleteAction.image = UIImage(systemName: "minus.circle.fill")
            let deleteConfig = UISwipeActionsConfiguration(actions: [deleteAction])
            return deleteConfig
        } else {
            let deleteConfig = UISwipeActionsConfiguration(actions: [])
            
            return deleteConfig
        }
    }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        if tableView == CDTable {
            let updateAction = UIContextualAction(style: .normal, title: "Edit") { [weak self] _, _, completionHandler in
                guard let self = self else { return }
                self.selectedMovie = self.CoreData[indexPath.row]
                self.performSegue(withIdentifier: "UpdateMovie", sender: indexPath)
                completionHandler(true)
            }
            updateAction.backgroundColor = .systemBlue
            updateAction.image = UIImage(systemName: "rectangle.and.pencil.and.ellipsis")
            return UISwipeActionsConfiguration(actions: [updateAction])
        }
        return UISwipeActionsConfiguration(actions: [])
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "UpdateMovie",
           let updateVC = segue.destination as? UpdateVC {
            updateVC.selectedMovie = self.CoreData[(sender as! IndexPath).row]
        }
    }
}

