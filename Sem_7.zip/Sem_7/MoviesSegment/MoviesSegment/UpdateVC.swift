//
//  UpdateVC.swift
//  MoviesSegment
//
//  Created by Sharma Aryan on 22/12/24.
//

import UIKit

class UpdateVC: UIViewController {

    @IBOutlet weak var updateimage: UITextField!
    @IBOutlet weak var updateURL: UITextField!
    @IBOutlet weak var updateBtn: UIButton!
    @IBOutlet weak var updateRating: UITextField!
    @IBOutlet weak var updateMovie: UITextField!
    var selectedMovie: MovieModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateMovie.text = selectedMovie.movie
        updateRating.text = String(selectedMovie.rating)
        updateimage.text = selectedMovie.image
        updateURL.text = selectedMovie.imdb_url
        // Do any additional setup after loading the view.
    }
    
    @IBAction func updateAction(_ sender: Any) {
        guard let movieData = updateMovie.text,
              let ratingData = updateRating.text,
              let rating = Double(ratingData),
              let imageData = updateimage.text,
              let urlData = updateURL.text else { return }
        
        CDManager().UpdateCD(movieUpdate: MovieModel(
            id: selectedMovie.id,
            movie: movieData,
            rating: rating,
            image: imageData,
            imdb_url: urlData
        ))
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
