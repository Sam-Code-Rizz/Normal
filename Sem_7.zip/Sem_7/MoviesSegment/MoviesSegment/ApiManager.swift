//
//  ApiManager.swift
//  MoviesSegment
//
//  Created by Sharma Aryan on 22/12/24.
//

import Foundation
import Alamofire

func fetchAF(completionHandler: @escaping(Result<[MovieModel], Error>)-> Void){

    let urlstr = "https://dummyapi.online/api/movies"
    
    AF.request(urlstr).responseDecodable(of: [MovieModel].self) { response in
        switch response.result {
        
        case .success(let data):
            completionHandler(.success(data))
            
        case .failure(let error):
            completionHandler(.failure(error))
        }
        
    }
    
}
