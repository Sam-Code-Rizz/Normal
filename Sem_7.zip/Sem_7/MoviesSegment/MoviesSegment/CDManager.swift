//
//  CDManager.swift
//  MoviesSegment
//
//  Created by Sharma Aryan on 22/12/24.
//

import Foundation
import CoreData
import UIKit

class CDManager {
    let delegate = UIApplication.shared.delegate as? AppDelegate
    
    func AddCD(movieData: MovieModel){
        guard let managedContext = delegate?.persistentContainer.viewContext else { return }
        guard let MovieEntity = NSEntityDescription.entity(forEntityName: "MovieEntity", in: managedContext) else { return }
        
        let movie = NSManagedObject(entity: MovieEntity, insertInto: managedContext)
        
        movie.setValue(movieData.id, forKey: "id")
        movie.setValue(movieData.movie, forKey: "movie")
        movie.setValue(movieData.rating, forKey: "rating")
        movie.setValue(movieData.image, forKey: "image")
        movie.setValue(movieData.imdb_url, forKey: "imdb_url")
        
        do{
            try managedContext.save()
            debugPrint("Data Saved Successfully...")
        }
        catch let err as NSError {
            debugPrint(err)
        }
    }
    
    func ReadCD()-> [MovieModel] {
        var movies: [MovieModel] = []
        let managedContext = delegate?.persistentContainer.viewContext
        
        let fetchRes = NSFetchRequest<NSFetchRequestResult>(entityName: "MovieEntity")
        
        do{
            let DataArr = try managedContext?.fetch(fetchRes)
            for item in DataArr as! [NSManagedObject]{
                let id = item.value(forKey: "id") as! Int64
                let rating = item.value(forKey: "rating") as! Double
                let imdb_url = item.value(forKey: "imdb_url") as! String
                let image = item.value(forKey: "image") as! String
                let movie = item.value(forKey: "movie") as! String
                movies.append(MovieModel(id: id, movie: movie, rating: rating, image: image, imdb_url: imdb_url))
            }
        } catch let err as NSError{
            debugPrint(err)
        }
        return movies
    }
    
    func UpdateCD(movieUpdate: MovieModel) {
        let managedContext = self.delegate?.persistentContainer.viewContext
        
        let fetchRes = NSFetchRequest<NSFetchRequestResult>(entityName: "MovieEntity")
        
        fetchRes.predicate = NSPredicate(format: "id = %d", movieUpdate.id)
        
        do {
            let result = try managedContext?.fetch(fetchRes)
            if let resultData = result as? [NSManagedObject] {
                for object in resultData {
                    object.setValue(movieUpdate.movie, forKey: "movie")
                    object.setValue(movieUpdate.rating, forKey: "rating")
                    object.setValue(movieUpdate.image, forKey: "image")
                    object.setValue(movieUpdate.imdb_url, forKey: "imdb_url")
                }
                try managedContext?.save()
                debugPrint("Data updated Successfully...")
            }
        } catch let err as NSError {
            debugPrint(err)
        }
    }
    
    func DeleteCD(movieDelete: MovieModel) {
        guard let managedContext = self.delegate?.persistentContainer.viewContext else { return }
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "MovieEntity")
        fetchRequest.predicate = NSPredicate(format: "id = %d", movieDelete.id)
        
        do {
            let result = try managedContext.fetch(fetchRequest)
            if let resultData = result as? [NSManagedObject] {
                for object in resultData {
                    managedContext.delete(object)
                }
                try managedContext.save()
                debugPrint("Data deleted Successfully...")
            }
        } catch let err as NSError {
            debugPrint(err)
        }
    }
}
